import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.http.request import Request
from ..items import MyprojectItem
from scrapy.http import response


class Myspider(scrapy.Spider):
    name = 'dmoz-odp'
    start_urls = ['https://dmoz-odp.org/Computers/Artificial_Intelligence',
                  'https://dmoz-odp.org/Computers/Ethics']

    def parse(self, response):
        for row in response.css('.title-and-desc').css('a'):
            link = row.attrib['href']
            yield Request(link, callback=self.parse)
            yield {
                'Website title': row.css('.site-title::text').get(),
                'Website link': row.attrib['href'],
                'Category': response.css('title::text').get()
            }





